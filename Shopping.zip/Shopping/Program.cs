using Shopping.Mapping;
using Mapster;
using HirePlatform;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Register Mapster mappings
builder.Services.AddScoped<IRegister, MappingConfigurations>();
TypeAdapterConfig.GlobalSettings.Scan(Assembly.GetExecutingAssembly());


TypeAdapterConfig.GlobalSettings.Scan(Assembly.GetExecutingAssembly());


//Calling Dependency class
builder.Services.AddDependecies(builder.Configuration);

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
 