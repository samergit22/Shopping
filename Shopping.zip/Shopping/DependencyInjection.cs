﻿using FluentValidation;
using FluentValidation.AspNetCore;
using HirePlatform.Authentication;
using HirePlatform.IServices;
using HirePlatform.Services;
using Mapster;
using MapsterMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SchoolSystem.IServices;
using SchoolSystem.Services;
using Shopping.Data;
using Shopping.IServices;
using Shopping.Models;
using Shopping.Services;
using System.Reflection;
using System.Text;

namespace HirePlatform
{
    public static class DependencyInjection 
    {
        public static IServiceCollection AddDependecies(this IServiceCollection services , IConfiguration configuration )
        {

            //Connection String for calling Data
            var CoonectionString = configuration.GetConnectionString("defaultConnection");
            services.AddDbContext<ShoppingData>(options =>
            options.UseSqlServer(CoonectionString));


            // Add services to the container.
            services.AddControllers();
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();


            //Add Global Mapster
            var mappingConfig = TypeAdapterConfig.GlobalSettings;
            mappingConfig.Scan(Assembly.GetExecutingAssembly());
            services.AddSingleton<IMapper>(new Mapper(mappingConfig));

            //Scoped for IAuthServices
            services.AddScoped<IUserService, UserService>();
            services.AddIdentity<User, IdentityRole>()
                .AddEntityFrameworkStores<ShoppingData>();

            //For Image File
            services.AddScoped<IFileService , FileService>();

            //for Cart 
            services.AddScoped<ICartService , CartService>();

            //for order
            services.AddScoped<IOrderService , OrderService>();

            //for Category
            services.AddScoped<ICategoryService, CategoryService>();

            //That's for Fluent Validation
            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            services.AddFluentValidationAutoValidation();
            
            //That's for Product
            services.AddScoped<IProductService , ProductService>();

            //Login And Register
            services.AddSingleton<IJwtProvider, JwtProvider>();

            //for JwtOptions
            services.AddOptions<JwtOptions>()
           .BindConfiguration(JwtOptions.SectionName)
           .ValidateDataAnnotations()
           .ValidateOnStart();
            var jwtSettings = configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>();

            //Services for Adding Authentication
            services.AddAuthentication(
                options =>
                {
                    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings?.Key!)),
                        ValidIssuer = jwtSettings?.Issuer,
                        ValidAudience = jwtSettings?.Audience,
                    };
                });


            //Add Validation for Email
            services.AddScoped<IEmailServices, EmailService>();
            return services;
        }
    }
}
